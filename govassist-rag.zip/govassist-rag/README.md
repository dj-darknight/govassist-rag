# GovAssist: a test-driven RAG assistant for international students working in Australia

**Case Studies in Data Science · Group 49**

GovAssist answers international students' questions about **working while studying in Australia** (student-visa work limits, pay, payslips, tax, super, unpaid trials, casual work, unfair treatment and where to get help) using only 15 official Australian Government web pages, and shows which page each answer came from. When the pages don't cover a question, it says so instead of guessing.

The project follows the **test-driven RAG** approach of Walert (Pathiyan Cherumanal et al., CHIIR '24). We wrote the test set and evaluation framework *before* building the system. We then measured retrieval on its own, measured the full system against a no-retrieval baseline, and changed one thing at a time.

> **Scope change since Milestone 1.** Milestone 1 targeted JobSeeker Payment. We narrowed the domain to international students working while studying. JobSeeker eligibility depends on individual income and asset tests, so it can't be evaluated reliably from a handful of pages. International students are a large, well-defined group with documented exposure to workplace exploitation, and the official information about them is spread across four agencies.

---

## 1. Architecture

```mermaid
flowchart LR
    Q[Student question] --> R{Retriever<br/>dense · BM25 · hybrid}
    KB[(15 official pages<br/>→ 237 chunks<br/>+ metadata)] --> R
    R -->|top-k chunks + score| T{Score ≥ threshold?<br/>tuned on dev set}
    T -- no --> A1[Abstain:<br/>'not in my sources']
    T -- yes --> L["Local LLM via Ollama<br/>answer only from sources,<br/>cite page IDs, or refuse"]
    L --> A2[Answer + cited<br/>official pages]
    L -->|model refuses| A1
```

| Component | Choice | Why |
|---|---|---|
| Knowledge base | 15 pages from Fair Work Ombudsman, Home Affairs, Study Australia, ATO (`data/raw/`, inventory in `docs/knowledge_base.csv`) | Authoritative, free to reuse, page-update dates recorded |
| Chunking | ~100 words, 40-word overlap, section-aware, page title prepended (`src/ingest.py`) | Chosen by a 100/200/400 sweep; changed from 200 in round v2 (see results) |
| Lexical retriever | BM25 (k1=0.9, b=0.4, Porter stemming, Lucene stopwords) | Same settings as Pyserini/Walert, so it's a faithful baseline |
| Dense retriever | `BAAI/bge-small-en-v1.5` embeddings, exact cosine search in NumPy | Small, runs on CPU. With ~100 chunks a vector database adds nothing |
| Hybrid | Reciprocal rank fusion of BM25 + dense | Evaluated in the retrieval sweep; no gain over dense alone |
| LLM | `llama3.2:3b` through Ollama, temperature 0, fixed seed | Free and local (as the brief recommends), deterministic for evaluation |
| Abstention | (1) retrieval-score threshold tuned on a separate dev set, (2) prompt instruction to refuse | Each is measured separately (see §4) |
| UI | Streamlit (`app.py`) | Browser prototype showing answer, source cards, match strength, disclaimer |

## 2. Setup (one time, ~20 minutes, mostly downloads)

1. **Python 3.10–3.12** and **Ollama** (<https://ollama.com/download>).
2. Pull the model (about 2 GB) and leave Ollama running:
   ```bash
   ollama pull llama3.2:3b
   ```
3. Install the Python packages:
   ```bash
   python -m venv .venv
   # Windows: .venv\Scripts\activate      macOS/Linux: source .venv/bin/activate
   pip install -r requirements.txt
   ```
   The first run downloads the embedding model (~130 MB) and, for BERTScore, `roberta-large` (~1.4 GB). Use `--quick` below to use a small BERTScore model instead.
4. Check everything works (offline, about 2 seconds):
   ```bash
   pytest
   ```

Different model? `GOVASSIST_LLM=qwen2.5:7b` (needs about 8 GB RAM free). All settings are in `src/config.py` and can be overridden with environment variables.

## 3. Running the experiment

```bash
python run_all.py            # everything, in order (~30–60 min on a laptop CPU)
python run_all.py --quick    # 200-word chunks only + fast BERTScore (~20 min)
```

Or step by step:

| Step | Command | Output |
|---|---|---|
| Chunk the pages | `python -m src.ingest` | `data/processed/chunks_w100_o40.jsonl` |
| **Evaluation 1: retrieval** | `python -m src.eval_retrieval` | `results/retrieval/summary.csv`, TREC runs + qrels |
| Tune abstention threshold (dev set only) | `python -m src.tune_threshold --retriever dense` | `results/threshold_cosine.json` |
| **Evaluation 2: end-to-end** | `python -m src.eval_generation --tag v1` | `results/generation/v1/summary.csv`, answers, blind grading sheet |
| Manual grading | fill `grading_sheet.csv` ([guide](docs/grading_guide.md)), then `python -m src.grading --tag v1` | `manual_summary.csv` with Cohen's kappa |
| Figures | `python -m src.make_figures` | `results/figures/*.png` |
| Demo | `streamlit run app.py` | browser app |
| Walert reproduction | open `notebooks/walert_pyserini_reproduction.ipynb` in Google Colab | reproduction tables |

**Improvement rounds:** change one setting, re-run with a new tag, compare. For example, `python run_all.py --tag v2 --top-k 6`. Every round is appended to `results/generation/summary_all.csv` and plotted in `improvement_rounds.png`.

## 4. Evaluation framework

### Test set (`evaluation/test_questions.csv`), written before the system

| Type | n | What it tests |
|---|---|---|
| Known | 15 | Answer stated directly on a page (one anchored on each document) |
| Inferred | 10 | Realistic scenarios that need facts combined or applied (e.g. "I'm doing a PhD; can my wife work full-time during semester?") |
| Out-of-KB, far | 5 | Clearly off-topic (Medicare, housing, citizenship…) → should abstain |
| Out-of-KB, near | 5 | *Sounds* in scope but the pages don't answer it (award rates, super guarantee %, 485 visa hours…) → should abstain. This is where hallucination actually happens. |

Each answerable question lists its relevant documents, the first being the primary source. Graded relevance follows Walert: primary = 2, other relevant = 1. A separate **dev set** (`evaluation/dev_questions.csv`, 8 questions) is used only to tune the abstention threshold, so test results are not tuned to the test set.

### Metrics

| Dimension | Metric | How |
|---|---|---|
| Retrieval effectiveness | NDCG@1/3/5, MRR, Hit@3, by question type | Automatic (`src/metrics.py`, cross-checked against ranx) |
| **Abstention (Walert's effectiveness metric)** | % of out-of-KB questions left unanswered, split far/near | Automatic |
| Cost of abstaining | % of answerable questions wrongly refused | Automatic |
| Answer similarity | ROUGE-1 F1, BERTScore F1 vs reference answers | Automatic (as in Walert) |
| Correctness | correct / partial / incorrect / refused | Two blind human graders + Cohen's kappa |
| Faithfulness | every claim supported by the official pages? | Two blind human graders + Cohen's kappa |
| Citation accuracy | cited a relevant page? cited a page it wasn't given? | Automatic |

### Systems compared

`llm_only` (same LLM, no retrieval: the "does RAG add value?" baseline) · `bm25_rag` · `dense_rag` · `dense_rag_threshold` · **`dense_rag_threshold_prompt` (GovAssist)** · `hybrid_rag_threshold_prompt` (improvement candidate).

## 5. Results so far

*Numbers below come from runs of the code in this repository. Sections marked "run locally" need Ollama and the embedding model on a team laptop.*

### Walert reproduction (exact)

Scoring Walert's published BM25 run with our code and with ranx gives identical numbers. The Colab notebook rebuilds the index with Pyserini and checks that its ranking matches.

| Walert BM25 | n | NDCG@1 | NDCG@3 | NDCG@5 |
|---|---|---|---|---|
| Known | 84 | 0.512 | 0.491 | 0.473 |
| Inferred | 12 | 0.167 | 0.257 | 0.329 |

This corrects Milestone 1's inferred figure (0.083 with `rank_bm25`). The difference comes from the BM25 implementation. We also found that ranx's `make_comparable=True` modifies the run object in place, which zeroes a second question group scored with the same run object. From Walert's published generation outputs, their Falcon RAG left only **10–20% of out-of-KB questions unanswered**, i.e. it answered most questions it had no evidence for.

### Evaluation 1: retrieval on our test set

NDCG@3 (graded relevance, document level). Full table in `results/retrieval/summary.csv`.

| Retriever | Chunk size | Known | Inferred | All answerable | Hit@3 |
|---|---|---|---|---|---|
| BM25 | 100 | 0.734 | 0.700 | 0.721 | 0.88 |
| BM25 | 200 | 0.768 | 0.593 | 0.698 | 0.88 |
| BM25 | 400 | 0.674 | 0.603 | 0.646 | 0.88 |
| **Dense** | **100** | **0.889** | **0.937** | **0.908** | **1.00** |
| Dense | 200 | 0.804 | 0.900 | 0.842 | 0.96 |
| Dense | 400 | 0.904 | 0.863 | 0.888 | 1.00 |
| Hybrid | 100 | 0.880 | 0.906 | 0.891 | 1.00 |
| Hybrid | 200 | 0.889 | 0.870 | 0.882 | 1.00 |
| Hybrid | 400 | 0.885 | 0.809 | 0.855 | 1.00 |

Dense retrieval beats BM25 on every setting, and most clearly on inferred (scenario) questions, which rarely share wording with the page (0.59 → 0.90 at 200 words). Hybrid fusion adds nothing over dense here.

**Abstention by score threshold (tuned on the dev set only).** A BM25 threshold stops 4 of 5 *far* out-of-KB questions with 0 of 25 answerable questions refused, but 0 of 5 *near-miss* questions. Retrieval scores catch obviously off-topic questions; questions that sound in scope need the LLM's prompt-based refusal as well.

### Evaluation 2: end-to-end (llama3.2:3b, top-4 passages)

Round **v1** (200-word chunks) compared all systems; round **v2** changed only the chunk size to 100 words (and re-tuned the threshold on the dev set).

| System | Out-of-KB unanswered (far / near) | Answerable wrongly refused | ROUGE-1 | BERTScore | Cited a relevant page |
|---|---|---|---|---|---|
| LLM only (no retrieval) | **0%** (0 / 0) | 8% | 0.25 | 0.86 | – |
| BM25 RAG | 40% (40 / 40) | 4% | 0.41 | 0.89 | 83% |
| Dense RAG | 50% (40 / 60) | 4% | 0.45 | 0.90 | 92% |
| Dense RAG + threshold | 70% (100 / 40) | 4% | 0.43 | 0.89 | 83% |
| Dense RAG + threshold + prompt, v1 | 90% (100 / 80) | 12% | 0.45 | 0.90 | 86% |
| **GovAssist v2 (100-word chunks)** | **90% (100 / 80)** | **4%** | 0.42 | 0.89 | **96%** |

- **Without retrieval, the LLM answered every one of the 10 questions it had no evidence for** (e.g. it invented work-hour limits for the 485 visa and a meaning for "DASP"). GovAssist left 9 of 10 unanswered, compared with 10–20% for Walert's published RAG.
- **Each abstention layer adds something:** the threshold alone catches all far questions but only 40% of near misses; adding the prompt instruction raises near misses to 80%.
- **The test-driven loop (v1 → v2):** v1's weakness was refusing real questions (3 of 25). The retrieval sweep showed 100-word chunks rank the right page higher, so v2 switched chunk size: wrongly refused answerable questions fell to 1 of 25 and relevant citations rose from 86% to 96%, with no loss in out-of-KB refusals.
- **Run-to-run variation:** the unchanged LLM-only baseline scored 8% false refusals in v1 and 12% in v2, so the local LLM is not perfectly deterministic and differences of about one question (4 points) are within noise. The small ROUGE change between v1 and v2 is not meaningful.

**Remaining failures (v2).**
- *K12, workers compensation:* refused by the threshold (score 0.706 vs threshold 0.708) even though the right page was retrieved: the cost of a threshold tuned on only 8 dev questions.
- *O08, super guarantee percentage (not in the sources):* instead of refusing, it repeated the outdated "$450 a month" statement from the Study Australia page, faithful to the source but stale (see limitations).
- Manual grading (below) captures errors the automatic metrics miss, e.g. an answer on unfair dismissal that cited the right page but misread the 12-month small-business rule.

**Manual correctness and faithfulness:** two blind graders, 50 answers (LLM-only vs GovAssist, v1). *Results: run `python -m src.grading --tag v1` and paste `results/generation/v1/manual_summary.csv` here.*

Figures: `results/figures/` (retrieval by type, chunk-size sweep, score separation, abstention trade-off, value comparison, improvement rounds).

## 6. Ethics, standards and limitations

- **Information, not advice.** In Australia, immigration assistance is a regulated activity (only registered migration agents and lawyers may provide it). GovAssist presents itself as general information from official pages, points to Home Affairs, the Fair Work Ombudsman or a registered migration agent, and its prompt forbids telling someone what they personally are eligible for.
- **Abstention over guessing.** A confident wrong answer about visa work limits could lead a student to breach condition 8105 and risk cancellation. We report both sides of the trade-off: questions correctly refused and answerable questions wrongly refused.
- **Currency of sources.** Official pages change (the National Minimum Wage changes every 1 July). Every document carries its page-updated and retrieval dates, and answers link to the live page. The knowledge base is a snapshot from **29 September 2026**.
- **Official pages can disagree or be out of date.** The Study Australia tax page (D11) and the Home Affairs page (D03) still describe a $450-per-month threshold for super, which was removed from 1 July 2022; the ATO's own page (D14) doesn't mention it. GovAssist faithfully repeats what its sources say, so faithfulness is not the same as real-world correctness. Answers about super are flagged for this in our analysis.
- **Privacy.** Questions are processed locally (local LLM, no external API) and not stored.
- **Fairness.** English only. The Fair Work Ombudsman offers help in 30+ languages, and multilingual queries are future work. We report results separately for known vs inferred questions and far vs near out-of-KB questions so weaknesses aren't averaged away.
- **Scale and variance.** 35 test questions and two graders support comparisons between systems but not fine-grained statistical claims, and the local LLM varies by about one question between identical runs. The v2 chunk size was chosen from a sweep over the test questions, so the v2 gain is slightly optimistic. With a 3B-parameter LLM, some errors come from misreading correctly retrieved pages rather than from retrieval.

## 7. Repository map

```
data/raw/               15 official pages as text (header: title, agency, URL, dates)
data/processed/         chunks (JSONL) and cached embeddings
docs/knowledge_base.csv document inventory
docs/grading_guide.md   instructions for the two human graders
evaluation/             test_questions.csv (35) and dev_questions.csv (8)
src/                    ingest, retrieve, generate, rag, metrics, eval_*, tune_threshold, grading, make_figures
app.py                  Streamlit demo
notebooks/              Walert/Pyserini reproduction (Colab)
tests/                  pytest suite (offline, uses mock encoder + mock LLM)
results/                all generated tables, TREC runs and figures
```

`results_mock/` (git-ignored) is produced only by offline dry runs with `GOVASSIST_EMBED_MODEL=mock` / `GOVASSIST_LLM=mock`. Never report numbers from it.

## 8. Sources

Knowledge-base pages: see `docs/knowledge_base.csv` (Fair Work Ombudsman, Department of Home Affairs, Study Australia/Austrade, Australian Taxation Office; retrieved 29 Sep 2026).

- Pathiyan Cherumanal, S. et al. (2024). *Walert: Putting Conversational Information Seeking Knowledge into Action by Building and Evaluating a Large Language Model-Powered Chatbot.* CHIIR '24. <https://doi.org/10.1145/3627508.3638309> · code: <https://github.com/rmit-ir/walert>
- Lewis, P. et al. (2020). Retrieval-Augmented Generation for Knowledge-Intensive NLP Tasks. NeurIPS 33.
- Cormack, G., Clarke, C. & Büttcher, S. (2009). Reciprocal rank fusion outperforms Condorcet and individual rank learning methods. SIGIR '09.
- Es, S. et al. (2024). RAGAs: Automated Evaluation of Retrieval Augmented Generation. EACL 2024.

**AI use:** code, the draft test set and this README were drafted with Claude (Anthropic) and reviewed, run and verified by the team. Reference answers were checked against the official pages by team members (see `verified_by` in the test set). This is declared in our Condition 3 statement.
