# Manual grading guide

Two team members grade independently, without discussing, then we measure how often they agree (Cohen's kappa).

## The sheet

`results/generation/<tag>/grading_sheet.csv` has one row per answer, shuffled. **The system that wrote each answer is hidden** (the key is in `grading_key.csv`; don't open it until both of you are done). Grader 1 fills the `grader1_*` columns, grader 2 the `grader2_*` columns. Use the exact lowercase labels below.

Keep `data/raw/` open: the `relevant_docs` column tells you which official pages hold the answer (e.g. `D03;D02` → `data/raw/D03_...txt`, `data/raw/D02_...txt`).

## `correctness`: does the answer give the right information?

Compare with `reference_answer` **and** the official pages (the reference is a summary; a correct fact from the pages that the reference doesn't mention is fine).

| label | when |
|---|---|
| `correct` | All key facts in the reference are there and nothing stated is wrong. Extra correct detail is fine. |
| `partial` | Some key facts are right, but something important is missing or slightly off (e.g. says "48 hours" but not "per fortnight"). |
| `incorrect` | Main point is wrong, or it states something false (wrong number, wrong rule, wrong agency). |
| `refused` | It declined to answer ("I don't have enough information…"). |

## `supported`: is every claim backed by the official pages? (faithfulness)

| label | when |
|---|---|
| `yes` | Every factual claim can be found in the official pages (`data/raw`). |
| `partly` | Most claims are backed, but at least one claim isn't in the pages (even if it might be true in real life). |
| `no` | The main claim isn't in the pages, or contradicts them. |
| *(leave blank)* | The answer was `refused`. |

A claim that is true in the real world but **not in our pages** is still `partly`/`no`. We are measuring whether the system stays grounded in official sources, not whether the model happens to know the answer.

## Examples

**Q:** Can my employer take money out of my wages if I accidentally break something?
- "No. Employers can't deduct money for accidental breakages [D01]." → `correct`, `yes`
- "Only if you signed an agreement allowing it." → `incorrect`, `no` (the pages say accidental breakage can't be deducted)
- "No, and you can report it to the Fair Work Commission within 21 days." → `partial`, `partly` (the 21-day rule is about unfair dismissal, not wages)

## When you're done

```bash
python -m src.grading --tag v1
python -m src.make_figures
```

Report the kappa values. Roughly: above 0.6 is substantial agreement, 0.4–0.6 is moderate, below 0.4 means the labels need discussing. After computing kappa, the two graders can resolve disagreements together and note what caused them. That is a useful sentence for the limitations section.
