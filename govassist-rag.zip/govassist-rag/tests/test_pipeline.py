"""Automated tests. They run offline (mock encoder + mock LLM), so no model downloads are needed.

Run:  pytest -q
"""
import os

os.environ["GOVASSIST_EMBED_MODEL"] = "mock"
os.environ["GOVASSIST_LLM"] = "mock"

import pandas as pd  # noqa: E402
import pytest  # noqa: E402

from src import config  # noqa: E402
from src.ingest import build_chunks, load_inventory, parse_raw  # noqa: E402
from src.metrics import (citation_scores, cited_docs, cohens_kappa, graded_qrels,  # noqa: E402
                         is_abstention, ndcg_at_k, rouge1_f)
from src.rag import GovAssist  # noqa: E402
from src.retrieve import BM25Retriever, top_documents  # noqa: E402
from src.tune_threshold import best_threshold  # noqa: E402


@pytest.fixture(scope="module")
def chunks():
    return build_chunks(200, 40)


# ---------------------------------------------------------------- knowledge base
def test_inventory_has_15_documents_with_files():
    inv = load_inventory()
    assert len(inv) == 15
    for doc_id, meta in inv.items():
        path = config.RAW_DIR / meta["filename"]
        assert path.exists(), path
        header, body = parse_raw(path)
        assert header[0] == meta["title"], f"{doc_id}: first header line should be the title"
        assert len(body.split()) > 100, f"{doc_id}: body looks empty"
        assert meta["source_url"].startswith("https://") and ".gov.au" in meta["source_url"]


def test_chunks_have_metadata_and_unique_ids(chunks):
    ids = [c["chunk_id"] for c in chunks]
    assert len(ids) == len(set(ids))
    assert {c["document_id"] for c in chunks} == set(load_inventory())
    for c in chunks:
        for key in ("document_id", "title", "agency", "source_url", "text", "page_last_updated"):
            assert c[key], (c["chunk_id"], key)
        assert c["chunk_id"].startswith(c["document_id"] + "_C")
        assert len(c["text"].split()) <= 200 + 60  # size + title line + carried heading


# ---------------------------------------------------------------- test set
def test_test_set_composition():
    q = pd.read_csv(config.TEST_QUESTIONS)
    assert len(q) == 35 and q.question_id.is_unique
    assert q.question_type.value_counts().to_dict() == {"known": 15, "inferred": 10, "out_of_kb": 10}
    assert (q[q.question_type == "out_of_kb"].relevant_docs == "NONE").all()
    assert (q[q.question_type == "out_of_kb"].expected_behavior == "ABSTAIN").all()
    docs = set(load_inventory())
    for r in q[q.question_type != "out_of_kb"].itertuples():
        assert set(graded_qrels(r.relevant_docs)) <= docs, r.question_id


def test_dev_set_does_not_overlap_test_set():
    t, d = pd.read_csv(config.TEST_QUESTIONS), pd.read_csv(config.DEV_QUESTIONS)
    assert not set(t.question) & set(d.question)


# ---------------------------------------------------------------- metrics
def test_graded_qrels():
    assert graded_qrels("D03;D02") == {"D03": 2, "D02": 1}
    assert graded_qrels("NONE") == {}


def test_ndcg():
    q = {"D01": 2, "D02": 1}
    assert ndcg_at_k(["D01", "D02"], q, 3) == pytest.approx(1.0)
    assert ndcg_at_k(["D09", "D08"], q, 3) == 0.0
    assert 0 < ndcg_at_k(["D02", "D01"], q, 3) < 1
    assert ndcg_at_k(["D01"], {}, 3) is None


@pytest.mark.parametrize("text,expected", [
    (config.ABSTAIN_MESSAGE, True),
    ("I don't have enough information to answer that.", True),
    ("The sources do not contain information about Medicare.", True),
    ("You can work up to 48 hours a fortnight while your course is in session [D03].", False),
    ("The sources don't mention award rates, but the National Minimum Wage is $26.44 per hour [D04] "
     "and applies to employees not covered by an award or agreement, so check your award as well [D05].", False),
    ("", True),
])
def test_abstention_detection(text, expected):
    assert is_abstention(text) is expected


def test_citations():
    a = "You get a payslip within one working day [D12][D13]. Cash in hand is illegal [D01, D05]."
    assert cited_docs(a) == ["D12", "D13", "D01", "D05"]
    s = citation_scores(a, {"D01": 2, "D12": 1}, {"D12", "D13", "D01", "D05"})
    assert s["cite_precision"] == 0.5 and s["cite_hit"] == 1.0 and s["cite_valid"] == 1.0
    assert citation_scores("[D07] x", {"D01": 2}, {"D01"})["cite_valid"] == 0.0


def test_rouge1():
    assert rouge1_f("the cat sat", "the cat sat") == pytest.approx(1.0)
    assert rouge1_f("dogs", "cats") == 0.0


def test_kappa():
    assert cohens_kappa(["a", "b", "a"], ["a", "b", "a"]) == pytest.approx(1.0)


# ---------------------------------------------------------------- retrieval + pipeline
def test_bm25_finds_minimum_wage_page(chunks):
    r = BM25Retriever(chunks)
    docs = [d for d, _ in top_documents(chunks, r.search("What is the National Minimum Wage as of 1 July 2026?", 10))]
    assert {"D04", "D05"} & set(docs[:3])


def test_threshold_picks_separating_value():
    t, bal, tpr, tnr = best_threshold([0.8, 0.7, 0.2, 0.1], [True, True, False, False])
    assert 0.2 < t < 0.7 and bal == 1.0


def test_pipeline_threshold_abstains_without_calling_llm():
    class Boom:
        def chat(self, messages):
            raise AssertionError("LLM should not be called")
    bot = GovAssist(retriever="bm25", threshold=1e9, llm=Boom())
    r = bot.answer("How do I get a Medicare card?")
    assert r["abstained"] and r["abstain_reason"] == "threshold"


def test_pipeline_answers_with_citation():
    bot = GovAssist(retriever="bm25", threshold=None)
    r = bot.answer("Can my employer deduct money from my wages if I accidentally break something?")
    assert not r["abstained"]
    assert r["citations"] and not r["invalid_citations"]


# ---------------------------------------------------------------- v3 additions
def test_robustness_set_is_separate():
    r = pd.read_csv(config.EVAL_DIR / "robustness_questions.csv")
    t, d = pd.read_csv(config.TEST_QUESTIONS), pd.read_csv(config.DEV_QUESTIONS)
    assert len(r) == 20 and r.question_id.is_unique
    assert not set(r.question) & set(t.question) and not set(r.question) & set(d.question)
    docs = set(load_inventory())
    for q in r[r.question_type != "out_of_kb"].itertuples():
        assert set(graded_qrels(q.relevant_docs)) <= docs, q.question_id


def test_unsupported_numbers():
    from src.metrics import unsupported_numbers
    src = ["If you earn more than $450 per month, your employer will pay super. $1,004.90 per week. one shift"]
    assert unsupported_numbers("above $450 a month, which is 9.5% [D11]", src) == ["9.5"]
    assert unsupported_numbers("$1004.90 per week, up to 1 shift [D04]", src) == []
    assert unsupported_numbers("you earn 15000", src, "I earn $15,000") == []


def test_number_check_withholds_invented_figure():
    class Inventor:
        def chat(self, messages):
            return "Your employer must pay 9.5% of your salary into super [D11].", 0.0
    bot = GovAssist(retriever="bm25", threshold=None, llm=Inventor(), number_check=True)
    r = bot.answer("How much super does my employer pay?")
    assert r["abstained"] and r["abstain_reason"] == "unsupported_number" and "9.5" in r["withheld_answer"]
    off = GovAssist(retriever="bm25", threshold=None, llm=Inventor(), number_check=False).answer("super?")
    assert not off["abstained"] and off["unsupported_numbers"] == ["9.5"]


def test_keep_threshold():
    from src.tune_threshold import keep_threshold
    t, _, tpr, _ = keep_threshold([0.8, 0.7, 0.65, 0.6, 0.5], [True, True, True, False, False], 0.95)
    assert tpr == 1.0 and 0.6 < t < 0.65
