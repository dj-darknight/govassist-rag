"""Run the whole experiment in order, stopping at the first failure.

    python run_all.py                 # full run (retrieval sweep, threshold, generation eval, figures)
    python run_all.py --quick         # 200-word chunks only, BERTScore with a small model
    python run_all.py --tag v2 --top-k 5   # another improvement round (generation only)
"""
import argparse
import subprocess
import sys


def run(*args):
    print("\n$ python -m " + " ".join(args), flush=True)
    if subprocess.call([sys.executable, "-m", *args]) != 0:
        sys.exit(f"step failed: {' '.join(args)}")


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--tag", default="v1")
    ap.add_argument("--top-k", default=None)
    ap.add_argument("--quick", action="store_true")
    args = ap.parse_args()

    if args.tag == "v1":
        run("pytest", "-q")
        run("src.ingest")
        run("src.eval_retrieval", *(["--chunk-sizes", "200"] if args.quick else []))
        run("src.tune_threshold", "--retriever", "dense")
        run("src.tune_threshold", "--retriever", "bm25")
    gen = ["src.eval_generation", "--tag", args.tag]
    if args.top_k:
        gen += ["--top-k", args.top_k]
    if args.quick:
        gen += ["--bertscore-model", "distilbert-base-uncased"]
    if args.tag != "v1":
        gen += ["--systems", "llm_only", "dense_rag_threshold_prompt"]
    run(*gen)
    run("src.make_figures")
    print("\nDone. Next: fill in the grading sheet (docs/grading_guide.md), then `python -m src.grading --tag "
          f"{args.tag}` and `python -m src.make_figures`.")


if __name__ == "__main__":
    main()
