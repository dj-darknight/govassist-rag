"""Central configuration for GovAssist RAG.

Every value can be overridden with an environment variable so experiments
can be run without editing code (e.g. GOVASSIST_LLM=qwen2.5:7b).
"""
import os
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

# ---- paths -----------------------------------------------------------------
RAW_DIR = ROOT / "data" / "raw"
PROCESSED_DIR = ROOT / "data" / "processed"
KB_CSV = ROOT / "docs" / "knowledge_base.csv"
EVAL_DIR = ROOT / "evaluation"
TEST_QUESTIONS = EVAL_DIR / "test_questions.csv"
DEV_QUESTIONS = EVAL_DIR / "dev_questions.csv"
# ---- chunking ----------------------------------------------------------------
CHUNK_WORDS = int(os.getenv("GOVASSIST_CHUNK_WORDS", 100))
CHUNK_OVERLAP = int(os.getenv("GOVASSIST_CHUNK_OVERLAP", 40))

# ---- retrieval ---------------------------------------------------------------
# bge-small is a small (33M parameter) retrieval-tuned embedding model that runs on CPU.
EMBED_MODEL = os.getenv("GOVASSIST_EMBED_MODEL", "BAAI/bge-small-en-v1.5")
# bge models expect this instruction in front of queries (not passages).
QUERY_PREFIX = os.getenv(
    "GOVASSIST_QUERY_PREFIX",
    "Represent this sentence for searching relevant passages: " if "bge" in EMBED_MODEL.lower() else "",
)
RETRIEVER = os.getenv("GOVASSIST_RETRIEVER", "dense")  # bm25 | dense | hybrid
TOP_K = int(os.getenv("GOVASSIST_TOP_K", 4))

# ---- generation --------------------------------------------------------------
LLM_MODEL = os.getenv("GOVASSIST_LLM", "llama3.2:3b")
OLLAMA_HOST = os.getenv("OLLAMA_HOST", "http://localhost:11434")
LLM_TEMPERATURE = 0.0  # deterministic answers for reproducible evaluation
LLM_SEED = 42
ABSTAIN_MESSAGE = "I don't have enough information in my sources to answer that."
# Withhold an answer that contains a figure (%, $, hours...) not found in the retrieved passages (added in v3).
NUMBER_CHECK = os.getenv("GOVASSIST_NUMBER_CHECK", "1") == "1"

DISCLAIMER = (
    "GovAssist gives general information from official Australian Government pages. "
    "It is not legal or migration advice. For advice about your visa, contact the "
    "Department of Home Affairs or a registered migration agent; for workplace problems, "
    "contact the Fair Work Ombudsman on 13 13 94."
)

# ---- results -----------------------------------------------------------------
# Dry runs with the offline mock encoder/LLM write to a separate folder so that
# placeholder numbers can never be mistaken for real results.
MOCK_MODE = EMBED_MODEL == "mock" or LLM_MODEL == "mock"
RESULTS_DIR = ROOT / ("results_mock" if MOCK_MODE else "results")


def threshold_file(retriever="dense"):
    """Dense and hybrid share the cosine-similarity scale; BM25 scores need their own threshold."""
    return RESULTS_DIR / f"threshold_{'bm25' if retriever == 'bm25' else 'cosine'}.json"
