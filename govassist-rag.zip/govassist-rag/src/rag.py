"""The GovAssist pipeline: retrieve -> (threshold check) -> generate -> parse citations.

    from src.rag import GovAssist
    bot = GovAssist()                      # uses src/config.py defaults
    result = bot.answer("Can I work more than 48 hours a fortnight?")
"""
import json

from . import config
from .generate import get_llm, no_rag_messages, rag_messages
from .ingest import load_chunks
from .metrics import cited_docs, is_abstention, unsupported_numbers
from .retrieve import get_retriever


def load_threshold(retriever="dense"):
    """Threshold tuned on the dev set by src.tune_threshold (None if not tuned yet)."""
    path = config.threshold_file(retriever)
    return json.loads(path.read_text()) if path.exists() else None


class GovAssist:
    def __init__(self, retriever="dense", top_k=None, chunk_words=None, overlap=None,
                 threshold=None, prompt_abstention=True, llm=None, number_check=None):
        """threshold: float, or "auto" to load the tuned threshold from results/, or None for no threshold."""
        self.chunks = load_chunks(chunk_words, overlap)
        self.retriever_name = retriever
        self.retriever = get_retriever(retriever, self.chunks)
        self.top_k = top_k or config.TOP_K
        if threshold == "auto":
            t = load_threshold(retriever)
            threshold = t["threshold"] if t else None
        self.threshold = threshold
        self.prompt_abstention = prompt_abstention
        # number-grounding guard: withhold answers containing figures not found in the retrieved passages
        self.number_check = config.NUMBER_CHECK if number_check is None else number_check
        self.llm = llm or get_llm()

    def retrieve(self, question):
        hits = self.retriever.search(question, self.top_k)
        return [dict(self.chunks[i], score=round(s, 4)) for i, s in hits]

    def answer(self, question):
        retrieved = self.retrieve(question)
        top_score = retrieved[0]["score"] if retrieved else float("-inf")
        base = {"question": question, "retrieved": retrieved, "top_score": top_score,
                "threshold": self.threshold, "latency_s": 0.0}
        if self.threshold is not None and top_score < self.threshold:
            return dict(base, answer=config.ABSTAIN_MESSAGE, abstained=True, abstain_reason="threshold", citations=[])
        text, latency = self.llm.chat(rag_messages(question, retrieved, allow_abstain=self.prompt_abstention))
        abstained = is_abstention(text)
        retrieved_ids = {c["document_id"] for c in retrieved}
        cites = [d for d in cited_docs(text)]
        bad_numbers = [] if abstained else unsupported_numbers(text, [c["text"] for c in retrieved], question)
        result = dict(base, answer=text, abstained=abstained, abstain_reason="model" if abstained else None,
                      citations=cites, invalid_citations=[d for d in cites if d not in retrieved_ids],
                      unsupported_numbers=bad_numbers, latency_s=round(latency, 2))
        if bad_numbers and self.number_check:
            result.update(withheld_answer=text, answer=config.ABSTAIN_MESSAGE, abstained=True,
                          abstain_reason="unsupported_number", citations=[])
        return result


class LLMOnly:
    """Baseline: the same LLM answering from its own knowledge, no retrieval."""

    retriever_name = "none"

    def __init__(self, llm=None):
        self.llm = llm or get_llm()

    def answer(self, question):
        text, latency = self.llm.chat(no_rag_messages(question))
        abstained = is_abstention(text)
        return {"question": question, "retrieved": [], "top_score": None, "threshold": None,
                "answer": text, "abstained": abstained, "abstain_reason": "model" if abstained else None,
                "citations": [], "invalid_citations": [], "unsupported_numbers": [],
                "latency_s": round(latency, 2)}
