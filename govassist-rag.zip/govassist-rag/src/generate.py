"""LLM access (Ollama) and the prompts used by GovAssist and by the no-retrieval baseline."""
import re
import time

from . import config

RAG_SYSTEM_PROMPT = """You are GovAssist, an information assistant for international students in Australia who want to know about working while studying.

Rules:
1. Answer ONLY with facts stated in the SOURCES below. Do not use outside knowledge, even if you think you know the answer.
2. After every sentence that uses a source, cite it with its ID in square brackets, e.g. [D03]. Only cite IDs that appear in SOURCES.
3. {abstain_rule}
4. Be concise: at most 120 words, plain language, no headings.
5. Give general information only. Do not tell the person what they personally are eligible for or what they should decide; point them to the right agency when relevant."""

ABSTAIN_RULE = ('If the SOURCES do not contain the information needed to answer, reply with exactly this sentence '
                'and nothing else: "' + config.ABSTAIN_MESSAGE + '"')
NO_ABSTAIN_RULE = "Answer as helpfully as the SOURCES allow."

NO_RAG_SYSTEM_PROMPT = """You are an assistant answering questions from international students in Australia about working while studying.
Answer in at most 120 words, in plain language, with no headings.
If you do not know the answer, reply with exactly: \"""" + config.ABSTAIN_MESSAGE + '"'


def format_sources(chunks):
    blocks = []
    for c in chunks:
        blocks.append(f"[{c['document_id']}] {c['title']} — {c['agency']}\n{c['text'].split(chr(10), 1)[-1]}")
    return "\n\n".join(blocks)


def rag_messages(question, chunks, allow_abstain=True):
    system = RAG_SYSTEM_PROMPT.format(abstain_rule=ABSTAIN_RULE if allow_abstain else NO_ABSTAIN_RULE)
    user = f"SOURCES:\n{format_sources(chunks)}\n\nQUESTION: {question}\n\nANSWER:"
    return [{"role": "system", "content": system}, {"role": "user", "content": user}]


def no_rag_messages(question):
    return [{"role": "system", "content": NO_RAG_SYSTEM_PROMPT}, {"role": "user", "content": question}]


class OllamaLLM:
    def __init__(self, model=None, host=None):
        import ollama
        self.model = model or config.LLM_MODEL
        self.client = ollama.Client(host=host or config.OLLAMA_HOST)

    def chat(self, messages):
        t0 = time.time()
        r = self.client.chat(model=self.model, messages=messages,
                             options={"temperature": config.LLM_TEMPERATURE, "seed": config.LLM_SEED,
                                      "num_ctx": 4096})
        text = r["message"]["content"] if isinstance(r, dict) else r.message.content
        return text.strip(), time.time() - t0


class MockLLM:
    """Offline stand-in used by tests and dry runs (GOVASSIST_LLM=mock). It copies the first
    source sentence that shares words with the question, or abstains. Never report its numbers."""

    model = "mock"

    def chat(self, messages):
        user = messages[-1]["content"]
        if "SOURCES:" not in user:
            return config.ABSTAIN_MESSAGE, 0.0
        q = set(re.findall(r"[a-z]{4,}", user.split("QUESTION:")[-1].lower()))
        best, best_overlap = None, 0
        for block in user.split("\n\n"):
            m = re.match(r"\[(D\d{2})\]", block)
            if not m:
                continue
            for sent in re.split(r"(?<=[.!?])\s+", block):
                overlap = len(q & set(re.findall(r"[a-z]{4,}", sent.lower())))
                if overlap > best_overlap:
                    best, best_overlap = f"{sent.strip()} [{m.group(1)}]", overlap
        if best_overlap < 2:
            return config.ABSTAIN_MESSAGE, 0.0
        return best, 0.0


def get_llm(model=None):
    model = model or config.LLM_MODEL
    return MockLLM() if model == "mock" else OllamaLLM(model)
