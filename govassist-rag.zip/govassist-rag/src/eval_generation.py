"""Evaluation #2 — end-to-end answers.

Runs each system over all 35 test questions and scores:
  * abstention on out-of-KB questions (Walert's "% unanswered"), split far / near
  * false refusals on answerable questions (the cost of abstaining too much)
  * citation accuracy (cited a relevant document? invented a citation?)
  * ROUGE-1 F1 and BERTScore F1 against the reference answers (as in Walert)
and writes a blind grading sheet for manual correctness / faithfulness scoring.

Systems (choose with --systems):
  llm_only                    same LLM, no retrieval (the "does RAG add value?" baseline)
  bm25_rag                    BM25 retrieval, prompt-based abstention
  dense_rag                   dense retrieval, prompt-based abstention
  dense_rag_threshold         dense retrieval, score-threshold abstention only
  dense_rag_threshold_prompt  dense retrieval, threshold + prompt abstention (GovAssist final)
  hybrid_rag_threshold_prompt BM25+dense fusion, threshold + prompt

Run:  python -m src.eval_generation --tag v1
      python -m src.eval_generation --tag v2 --top-k 5 --systems dense_rag_threshold_prompt
Outputs: results/generation/<tag>/{<system>.jsonl, per_question.csv, summary.csv,
         grading_sheet.csv, grading_key.csv} and results/generation/summary_all.csv
"""
import argparse
import json
import random

import pandas as pd

from . import config
from .generate import get_llm
from .metrics import citation_scores, graded_qrels, rouge1_f, strip_citations
from .rag import GovAssist, LLMOnly

ALL_SYSTEMS = ["llm_only", "bm25_rag", "dense_rag", "dense_rag_threshold",
               "dense_rag_threshold_prompt", "hybrid_rag_threshold_prompt"]
DEFAULT_SYSTEMS = ALL_SYSTEMS[:5]
FINAL_SYSTEM = "dense_rag_threshold_prompt"


def build_system(name, llm, top_k, chunk_words, number_check=False):
    kw = dict(top_k=top_k, chunk_words=chunk_words, llm=llm, number_check=number_check)
    if name == "llm_only":
        return LLMOnly(llm)
    if name == "bm25_rag":
        return GovAssist("bm25", **kw)
    if name == "dense_rag":
        return GovAssist("dense", **kw)
    if name == "dense_rag_threshold":
        return GovAssist("dense", threshold="auto", prompt_abstention=False, **kw)
    if name == "dense_rag_threshold_prompt":
        return GovAssist("dense", threshold="auto", **kw)
    if name == "hybrid_rag_threshold_prompt":
        return GovAssist("hybrid", threshold="auto", **kw)
    raise ValueError(name)


def bertscore(cands, refs, model_type):
    try:
        from bert_score import score
    except ImportError:
        print("  (bert-score not installed: skipping BERTScore)")
        return [None] * len(cands)
    _, _, f1 = score(cands, refs, lang="en", model_type=model_type, verbose=False)
    return [round(float(x), 4) for x in f1]


def score_rows(results, questions):
    rows = []
    for r, q in zip(results, questions.itertuples()):
        qrels = graded_qrels(q.relevant_docs)
        retrieved_ids = {c["document_id"] for c in r["retrieved"]}
        row = {
            "question_id": q.question_id, "question_type": q.question_type,
            "ookb_kind": q.ookb_kind if isinstance(q.ookb_kind, str) else "",
            "abstained": bool(r["abstained"]), "abstain_reason": r["abstain_reason"] or "",
            "top_score": r["top_score"], "retrieved_docs": ";".join(dict.fromkeys(c["document_id"] for c in r["retrieved"])),
            "citations": ";".join(r["citations"]), "latency_s": r["latency_s"], "answer": r["answer"],
            "unsupported_numbers": ";".join(r.get("unsupported_numbers") or []),
            "withheld_answer": r.get("withheld_answer", ""),
        }
        if q.question_type != "out_of_kb":
            row["rouge1"] = round(rouge1_f(strip_citations(r["answer"]), q.reference_answer), 4)
            if not r["abstained"]:
                row.update(citation_scores(r["answer"], qrels, retrieved_ids))
        rows.append(row)
    return rows


def summarise(df, system, tag):
    ans = df[df.question_type != "out_of_kb"]
    ookb = df[df.question_type == "out_of_kb"]
    answered = ans[~ans.abstained]
    s = {
        "tag": tag, "system": system, "n_answerable": len(ans), "n_out_of_kb": len(ookb),
        # --- abstention (Walert: % of out-of-KB questions left unanswered) ---
        "ookb_unanswered_pct": 100 * ookb.abstained.mean(),
        "ookb_far_unanswered_pct": 100 * ookb[ookb.ookb_kind == "far"].abstained.mean(),
        "ookb_near_unanswered_pct": 100 * ookb[ookb.ookb_kind == "near"].abstained.mean(),
        "false_refusal_pct": 100 * ans.abstained.mean(),
        "known_answered_pct": 100 * (1 - ans[ans.question_type == "known"].abstained.mean()),
        "inferred_answered_pct": 100 * (1 - ans[ans.question_type == "inferred"].abstained.mean()),
        # --- overlap with reference answers (all answerable questions; refusals score low) ---
        "rouge1_f": ans.rouge1.mean(),
        "bertscore_f1": ans.bertscore_f1.mean() if "bertscore_f1" in ans and ans.bertscore_f1.notna().any() else None,
        # --- citations (answered answerable questions) ---
        "answers_with_citation_pct": 100 * (answered.get("n_cited", pd.Series(dtype=float)).fillna(0) > 0).mean()
        if len(answered) else None,
        "citation_hit_pct": 100 * answered["cite_hit"].mean() if "cite_hit" in answered and len(answered) else None,
        "citation_precision_pct": 100 * answered["cite_precision"].mean() if "cite_precision" in answered and len(answered) else None,
        "invalid_citation_pct": 100 * (1 - answered["cite_valid"].dropna().mean())
        if "cite_valid" in answered and answered["cite_valid"].notna().any() else None,
        # answers (to any question) containing a figure not found in the retrieved passages
        "answers_with_unsupported_number_pct": 100 * (df.unsupported_numbers.fillna("") != "")[~df.abstained | (df.abstain_reason == "unsupported_number")].mean()
        if system != "llm_only" else None,
        "withheld_by_number_check": int((df.abstain_reason == "unsupported_number").sum()),
        "mean_latency_s": df.latency_s.mean(),
    }
    return {k: (round(v, 2) if isinstance(v, float) else v) for k, v in s.items()}


def write_grading_sheet(out_dir, per_system, questions, systems_to_grade, seed=7):
    rows = []
    for name in systems_to_grade:
        if name not in per_system:
            continue
        for r, q in zip(per_system[name], questions.itertuples()):
            if q.question_type == "out_of_kb":
                continue
            rows.append({"system": name, "question_id": q.question_id, "question_type": q.question_type,
                         "question": q.question, "reference_answer": q.reference_answer,
                         "relevant_docs": q.relevant_docs, "answer": r["answer"]})
    random.Random(seed).shuffle(rows)
    for i, r in enumerate(rows, start=1):
        r["row_id"] = f"G{i:03d}"
    key = pd.DataFrame(rows)[["row_id", "system", "question_id"]]
    sheet = pd.DataFrame(rows).drop(columns=["system"])
    sheet = sheet[["row_id", "question_id", "question_type", "question", "reference_answer", "relevant_docs", "answer"]]
    for g in ("grader1", "grader2"):
        sheet[f"{g}_correctness"] = ""   # correct | partial | incorrect | refused
        sheet[f"{g}_supported"] = ""     # yes | partly | no   (every claim backed by the official pages?)
    sheet["notes"] = ""
    sheet.to_csv(out_dir / "grading_sheet.csv", index=False)
    key.to_csv(out_dir / "grading_key.csv", index=False)
    print(f"  grading sheet: {len(sheet)} blind rows -> {(out_dir / 'grading_sheet.csv').relative_to(config.ROOT)}")


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--tag", default="v1", help="name of this evaluation round, e.g. v1, v2")
    ap.add_argument("--systems", nargs="+", default=DEFAULT_SYSTEMS, choices=ALL_SYSTEMS)
    ap.add_argument("--top-k", type=int, default=config.TOP_K)
    ap.add_argument("--chunk-words", type=int, default=config.CHUNK_WORDS)
    ap.add_argument("--grade", nargs="*", default=["llm_only", FINAL_SYSTEM],
                    help="systems to put in the manual grading sheet (give no names for no sheet)")
    ap.add_argument("--questions", default=str(config.TEST_QUESTIONS),
                    help="question file (default: the test set; e.g. evaluation/robustness_questions.csv)")
    ap.add_argument("--number-check", action="store_true",
                    help="withhold answers that contain figures not found in the retrieved passages (v3)")
    ap.add_argument("--bertscore-model", default="roberta-large",
                    help="BERTScore model (roberta-large is the standard; distilbert-base-uncased is much faster)")
    ap.add_argument("--no-bertscore", action="store_true")
    ap.add_argument("--limit", type=int, default=None, help="only run the first N questions (smoke test)")
    args = ap.parse_args()

    questions = pd.read_csv(args.questions)
    if args.limit:
        questions = questions.groupby("question_type").head(max(1, args.limit // 3)).reset_index(drop=True)
    out_dir = config.RESULTS_DIR / "generation" / args.tag
    out_dir.mkdir(parents=True, exist_ok=True)
    llm = get_llm()
    print(f"LLM: {getattr(llm, 'model', '?')} | top_k={args.top_k} | chunks={args.chunk_words} words | "
          f"number check={'on' if args.number_check else 'off'} | questions={len(questions)} | tag={args.tag}")

    per_system, summaries, all_rows = {}, [], []
    for name in args.systems:
        system = build_system(name, llm, args.top_k, args.chunk_words, args.number_check)
        if getattr(system, "threshold", "n/a") is None and "threshold" in name:
            raise SystemExit(f"{name} needs a tuned threshold: run `python -m src.tune_threshold --retriever "
                             f"{system.retriever_name}` first.")
        print(f"- {name}: answering {len(questions)} questions ...", flush=True)
        results = []
        for i, q in enumerate(questions.question, start=1):
            results.append(system.answer(q))
            print(f"    {i}/{len(questions)}", end="\r", flush=True)
        per_system[name] = results
        with open(out_dir / f"{name}.jsonl", "w", encoding="utf-8") as f:
            for q, r in zip(questions.question_id, results):
                slim = dict(r, retrieved=[{k: c[k] for k in ("chunk_id", "document_id", "score")} for c in r["retrieved"]])
                f.write(json.dumps(dict(slim, question_id=q), ensure_ascii=False) + "\n")
        rows = score_rows(results, questions)
        df = pd.DataFrame(rows)
        if not args.no_bertscore:
            mask = df.question_type != "out_of_kb"
            refs = questions.loc[mask, "reference_answer"].tolist()
            cands = [strip_citations(a) for a in df.loc[mask, "answer"]]
            df.loc[mask, "bertscore_f1"] = bertscore(cands, refs, args.bertscore_model)
        df.insert(0, "system", name)
        all_rows.append(df)
        summaries.append(summarise(df, name, args.tag))
        print(f"    done: {summaries[-1]['ookb_unanswered_pct']:.0f}% of out-of-KB unanswered, "
              f"{summaries[-1]['false_refusal_pct']:.0f}% false refusals")

    pd.concat(all_rows).to_csv(out_dir / "per_question.csv", index=False)
    summary = pd.DataFrame(summaries)
    summary.to_csv(out_dir / "summary.csv", index=False)
    all_path = config.RESULTS_DIR / "generation" / "summary_all.csv"
    if all_path.exists():
        prev = pd.read_csv(all_path)
        prev = prev[~((prev.tag == args.tag) & prev.system.isin(summary.system))]
        summary = pd.concat([prev, summary])
    summary.to_csv(all_path, index=False)
    if args.grade:
        write_grading_sheet(out_dir, per_system, questions, args.grade)

    pd.set_option("display.width", 200)
    print("\n" + pd.DataFrame(summaries).set_index("system").T.to_string())


if __name__ == "__main__":
    main()
