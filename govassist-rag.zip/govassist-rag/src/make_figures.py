"""Make report / presentation figures from the CSVs the evaluation scripts wrote.

Run:  python -m src.make_figures
Writes PNGs to results/figures/. Every number shown comes from a results CSV;
figures whose inputs don't exist yet are skipped with a message.
"""
import pandas as pd

from . import config

# Validated categorical palette (colour-blind safe on a light surface).
BLUE, ORANGE, AQUA = "#2a78d6", "#eb6834", "#1baf7a"
INK, INK2, GRID, SURFACE = "#0b0b0b", "#52514e", "#e4e3df", "#fcfcfb"
OUT = config.RESULTS_DIR / "figures"


def _setup():
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    plt.rcParams.update({
        "figure.facecolor": SURFACE, "axes.facecolor": SURFACE, "savefig.facecolor": SURFACE,
        "axes.edgecolor": GRID, "axes.labelcolor": INK2, "xtick.color": INK2, "ytick.color": INK2,
        "text.color": INK, "font.size": 11, "axes.titlesize": 13, "axes.titleweight": "bold",
        "axes.spines.top": False, "axes.spines.right": False, "axes.grid": True, "axes.grid.axis": "y",
        "grid.color": GRID, "grid.linewidth": 0.8, "axes.axisbelow": True, "legend.frameon": False,
    })
    return plt


def _bars(ax, groups, series, colors, values, fmt="{:.2f}"):
    """Grouped bars with a 2px gap between neighbours and value labels (text in ink, not series colour)."""
    n = len(series)
    width = 0.8 / n
    for j, (name, color) in enumerate(zip(series, colors)):
        xs = [i - 0.4 + width * (j + 0.5) for i in range(len(groups))]
        vals = [values[g][j] for g in groups]
        bars = ax.bar(xs, [v if v == v else 0 for v in vals], width * 0.94, color=color, label=name, zorder=2)
        for b, v in zip(bars, vals):
            if v == v:
                ax.annotate(fmt.format(v), (b.get_x() + b.get_width() / 2, b.get_height()),
                            xytext=(0, 3), textcoords="offset points", ha="center", fontsize=9, color=INK2)
    ax.set_xticks(range(len(groups)))
    ax.set_xticklabels(groups)


def retrieval_by_type(plt):
    path = config.RESULTS_DIR / "retrieval" / "summary.csv"
    if not path.exists():
        return print("skip retrieval_by_type: run src.eval_retrieval first")
    s = pd.read_csv(path)
    s = s[s.chunk_words == config.CHUNK_WORDS]
    retrievers = [r for r in ["bm25", "dense", "hybrid"] if r in set(s.retriever)]
    values = {r: [s[(s.retriever == r) & (s.question_type == t)]["ndcg@3"].mean() for t in ("known", "inferred")]
              for r in retrievers}
    fig, ax = plt.subplots(figsize=(7, 4.2))
    _bars(ax, retrievers, ["Known questions", "Inferred questions"], [BLUE, ORANGE], values)
    ax.set_ylim(0, 1.08)
    ax.set_ylabel("NDCG@3 (higher is better)")
    ax.set_title(f"Retrieval quality by retriever ({config.CHUNK_WORDS}-word chunks)", loc="left")
    ax.legend(loc="upper left", ncol=2)
    fig.tight_layout()
    fig.savefig(OUT / "retrieval_ndcg3_by_type.png", dpi=200)
    plt.close(fig)


def chunk_size_sweep(plt):
    path = config.RESULTS_DIR / "retrieval" / "summary.csv"
    if not path.exists():
        return
    s = pd.read_csv(path)
    s = s[s.question_type == "all_answerable"]
    sizes = sorted(s.chunk_words.unique())
    if len(sizes) < 2:
        return print("skip chunk_size_sweep: only one chunk size evaluated")
    fig, ax = plt.subplots(figsize=(7, 4.2))
    for r, c in zip(["bm25", "dense", "hybrid"], [BLUE, ORANGE, AQUA]):
        d = s[s.retriever == r].sort_values("chunk_words")
        if d.empty:
            continue
        ax.plot(d.chunk_words, d["ndcg@3"], color=c, lw=2, marker="o", ms=8, label=r,
                markeredgecolor=SURFACE, markeredgewidth=2, zorder=3)
        last = d.iloc[-1]
        ax.annotate(f"{r} {last['ndcg@3']:.2f}", (last.chunk_words, last["ndcg@3"]), xytext=(8, 0),
                    textcoords="offset points", va="center", fontsize=9, color=INK2)
    ax.set_xticks(sizes)
    ax.set_xlabel("Chunk size (words)")
    ax.set_ylabel("NDCG@3, all answerable questions")
    ax.set_ylim(0, 1.05)
    ax.set_xlim(min(sizes) - 30, max(sizes) + 110)
    ax.set_title("Effect of chunk size on retrieval", loc="left")
    ax.legend(loc="lower left", ncol=3)
    fig.tight_layout()
    fig.savefig(OUT / "chunk_size_sweep.png", dpi=200)
    plt.close(fig)


def score_separation(plt):
    path = config.RESULTS_DIR / "retrieval" / "top_scores.csv"
    if not path.exists():
        return
    s = pd.read_csv(path)
    tag = f"dense_w{config.CHUNK_WORDS}"
    s = s[s.config == tag]
    if s.empty:
        return print(f"skip score_separation: no {tag} run yet")
    fig, ax = plt.subplots(figsize=(7, 3.6))
    groups = [("Answerable", s[s.question_type != "out_of_kb"], BLUE, 1),
              ("Out-of-KB (far)", s[s.ookb_kind == "far"], ORANGE, 0),
              ("Out-of-KB (near)", s[s.ookb_kind == "near"], AQUA, -1)]
    for label, d, c, y in groups:
        ax.scatter(d.top1_score, [y] * len(d), s=70, color=c, edgecolor=SURFACE, linewidth=2, zorder=3)
    ax.set_yticks([g[3] for g in groups])
    ax.set_yticklabels([g[0] for g in groups])
    ax.grid(axis="x", color=GRID)
    ax.grid(axis="y", visible=False)
    ax.set_ylim(-1.6, 2.1)
    if config.threshold_file("dense").exists():
        import json
        t = json.loads(config.threshold_file("dense").read_text())
        if t.get("retriever_score") == "cosine":
            ax.axvline(t["threshold"], color=INK2, lw=1.5, ls="--")
            ax.annotate(f"threshold {t['threshold']:.3f}\n(tuned on dev set)", (t["threshold"], 2.0),
                        xytext=(6, 0), textcoords="offset points", fontsize=9, color=INK2, va="top")
    ax.set_xlabel("Top-1 cosine similarity (test questions)")
    ax.set_title("Top-1 retrieval score by question group", loc="left")
    fig.tight_layout()
    fig.savefig(OUT / "score_separation.png", dpi=200)
    plt.close(fig)


def abstention_tradeoff(plt, tag):
    path = config.RESULTS_DIR / "generation" / tag / "summary.csv"
    if not path.exists():
        return print(f"skip abstention_tradeoff: no generation results for {tag}")
    s = pd.read_csv(path)
    fig, ax = plt.subplots(figsize=(7, 4.8))
    ax.scatter(s.false_refusal_pct, s.ookb_unanswered_pct, s=90, color=BLUE, edgecolor=SURFACE, linewidth=2, zorder=3)
    # systems that land on the same point share one label
    for (x, y), grp in s.groupby(["false_refusal_pct", "ookb_unanswered_pct"]):
        label = "\n".join(n.replace("_", " ") for n in grp.system)
        ax.annotate(label, (x, y), xytext=(8, 4), textcoords="offset points", fontsize=9, color=INK, va="center")
    ax.set_xlim(-5, 105)
    ax.set_ylim(-5, 110)
    ax.grid(axis="x", color=GRID)
    ax.set_xlabel("False refusals: answerable questions refused (%)  — lower is better")
    ax.set_ylabel("Out-of-KB questions left unanswered (%)\nhigher is better")
    ax.annotate("ideal", (0, 100), xytext=(6, -14), textcoords="offset points", fontsize=9, color=INK2)
    ax.set_title(f"Abstention trade-off ({tag})", loc="left")
    fig.tight_layout()
    fig.savefig(OUT / f"abstention_tradeoff_{tag}.png", dpi=200)
    plt.close(fig)


def value_comparison(plt, tag, final="dense_rag_threshold_prompt"):
    gen = config.RESULTS_DIR / "generation" / tag / "summary.csv"
    man = config.RESULTS_DIR / "generation" / tag / "manual_summary.csv"
    if not gen.exists():
        return
    g = pd.read_csv(gen).set_index("system")
    if not {"llm_only", final} <= set(g.index):
        return print("skip value_comparison: need llm_only and the final system in the same tag")
    metrics = [("Out-of-KB\nunanswered", lambda s: g.loc[s, "ookb_unanswered_pct"] / 100),
               ("ROUGE-1", lambda s: g.loc[s, "rouge1_f"])]
    if pd.notna(g.loc[final, "bertscore_f1"]):
        metrics.append(("BERTScore", lambda s: g.loc[s, "bertscore_f1"]))
    if man.exists():
        m = pd.read_csv(man).set_index("system")
        if {"llm_only", final} <= set(m.index):
            metrics += [("Correctness\n(manual)", lambda s: m.loc[s, "correctness_score"]),
                        ("Faithfulness\n(manual)", lambda s: m.loc[s, "faithfulness_score"])]
    labels = [lab for lab, _ in metrics]
    values = {lab: [f("llm_only"), f(final)] for lab, f in metrics}
    fig, ax = plt.subplots(figsize=(8, 4.4))
    _bars(ax, labels, ["LLM only (no retrieval)", "GovAssist RAG"], [ORANGE, BLUE], values)
    ax.set_ylim(0, 1.12)
    ax.set_ylabel("Score (0–1)")
    ax.set_title(f"Does retrieval add value? ({tag})", loc="left")
    ax.legend(loc="upper right", ncol=2)
    fig.tight_layout()
    fig.savefig(OUT / f"value_comparison_{tag}.png", dpi=200)
    plt.close(fig)


def improvement_rounds(plt, final="dense_rag_threshold_prompt"):
    path = config.RESULTS_DIR / "generation" / "summary_all.csv"
    if not path.exists():
        return
    s = pd.read_csv(path)
    s = s[(s.system == final) & ~s.tag.str.startswith("rob_")]
    if s.tag.nunique() < 2:
        return print("skip improvement_rounds: only one round (tag) so far")
    tags = list(dict.fromkeys(s.tag))
    fig, ax = plt.subplots(figsize=(7, 4.2))
    for col, label, c in [("ookb_unanswered_pct", "Out-of-KB unanswered %", BLUE),
                          ("false_refusal_pct", "False refusal %", ORANGE)]:
        ys = [s[s.tag == t][col].iloc[-1] for t in tags]
        ax.plot(tags, ys, color=c, lw=2, marker="o", ms=8, markeredgecolor=SURFACE, markeredgewidth=2,
                label=label, zorder=3)
        for x, y in zip(tags, ys):
            ax.annotate(f"{y:.0f}", (x, y), xytext=(0, 8), textcoords="offset points", ha="center",
                        fontsize=9, color=INK2)
    ax.set_ylim(-5, 115)
    ax.set_ylabel("%")
    ax.set_title("GovAssist across improvement rounds", loc="left")
    ax.legend(loc="center right")
    fig.tight_layout()
    fig.savefig(OUT / "improvement_rounds.png", dpi=200)
    plt.close(fig)


def robustness(plt, final="dense_rag_threshold_prompt"):
    """Test set vs casually worded robustness set, per round."""
    path = config.RESULTS_DIR / "generation" / "summary_all.csv"
    if not path.exists():
        return
    s = pd.read_csv(path)
    s = s[s.system == final]
    rounds = [t for t in dict.fromkeys(s.tag) if not t.startswith("rob_") and f"rob_{t}" in set(s.tag)]
    if not rounds:
        return print("skip robustness: no rob_<tag> runs yet")
    labels, values = [], {}
    for t in rounds:
        for kind, tag in (("test set", t), ("casual questions", f"rob_{t}")):
            row = s[s.tag == tag].iloc[-1]
            lab = f"{t}\n{kind}"
            labels.append(lab)
            values[lab] = [row.false_refusal_pct, row.ookb_unanswered_pct]
    fig, ax = plt.subplots(figsize=(8.5, 4.4))
    _bars(ax, labels, ["Answerable wrongly refused %", "Out-of-KB unanswered %"], [ORANGE, BLUE], values, fmt="{:.0f}")
    ax.set_ylim(0, 115)
    ax.set_ylabel("%")
    ax.set_title("Robustness: neatly written test set vs casually worded questions", loc="left")
    ax.legend(loc="upper left", ncol=2)
    fig.tight_layout()
    fig.savefig(OUT / "robustness.png", dpi=200)
    plt.close(fig)


def main():
    plt = _setup()
    OUT.mkdir(parents=True, exist_ok=True)
    retrieval_by_type(plt)
    chunk_size_sweep(plt)
    score_separation(plt)
    gen_dir = config.RESULTS_DIR / "generation"
    tags = sorted(p.name for p in gen_dir.iterdir() if p.is_dir() and not p.name.startswith("rob_")) \
        if gen_dir.exists() else []
    for tag in tags:
        abstention_tradeoff(plt, tag)
        value_comparison(plt, tag)
    improvement_rounds(plt)
    robustness(plt)
    print(f"figures in {OUT.relative_to(config.ROOT)}/:", ", ".join(sorted(p.name for p in OUT.glob("*.png"))))


if __name__ == "__main__":
    main()
