"""Combine the two graders' manual labels into correctness / faithfulness scores.

Fill in results/generation/<tag>/grading_sheet.csv first (see docs/grading_guide.md),
then run:  python -m src.grading --tag v1

Scores: correctness correct=1, partial=0.5, incorrect=0, refused=0
        supported   yes=1, partly=0.5, no=0 (refusals are left out)
Agreement between graders is reported as Cohen's kappa.
"""
import argparse

import pandas as pd

from . import config
from .metrics import cohens_kappa

CORRECT = {"correct": 1.0, "partial": 0.5, "incorrect": 0.0, "refused": 0.0}
SUPPORTED = {"yes": 1.0, "partly": 0.5, "no": 0.0}


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--tag", default="v1")
    args = ap.parse_args()
    d = config.RESULTS_DIR / "generation" / args.tag
    sheet = pd.read_csv(d / "grading_sheet.csv", dtype=str).fillna("")
    key = pd.read_csv(d / "grading_key.csv")
    df = sheet.merge(key[["row_id", "system"]], on="row_id")
    for col in [c for c in df if c.endswith(("_correctness", "_supported"))]:
        df[col] = df[col].str.strip().str.lower()

    graders = [g for g in ("grader1", "grader2") if (df[f"{g}_correctness"] != "").any()]
    if not graders:
        raise SystemExit("No grades found yet: fill in grading_sheet.csv first.")
    for g in graders:
        bad = set(df[f"{g}_correctness"]) - set(CORRECT) - {""}
        bad |= set(df[f"{g}_supported"]) - set(SUPPORTED) - {"", "n/a"}
        if bad:
            raise SystemExit(f"{g}: unexpected labels {sorted(bad)}")
        df[f"{g}_c"] = df[f"{g}_correctness"].map(CORRECT)
        df[f"{g}_s"] = df[f"{g}_supported"].map(SUPPORTED)
    df["correctness"] = df[[f"{g}_c" for g in graders]].mean(axis=1)
    df["supported"] = df[[f"{g}_s" for g in graders]].mean(axis=1)

    rows = []
    for system, grp in df.groupby("system"):
        rows.append({
            "tag": args.tag, "system": system, "n_graded": int(grp.correctness.notna().sum()),
            "correctness_score": round(grp.correctness.mean(), 3),
            "fully_correct_pct": round(100 * (grp.correctness == 1).mean(), 1),
            "known_correctness": round(grp[grp.question_type == "known"].correctness.mean(), 3),
            "inferred_correctness": round(grp[grp.question_type == "inferred"].correctness.mean(), 3),
            "faithfulness_score": round(grp.supported.mean(), 3),
            "unsupported_claims_pct": round(100 * (grp.supported == 0).sum() / max(1, grp.supported.notna().sum()), 1),
        })
    out = pd.DataFrame(rows)
    if len(graders) == 2:
        out["kappa_correctness"] = round(cohens_kappa(df.grader1_correctness, df.grader2_correctness), 3)
        out["kappa_supported"] = round(cohens_kappa(df.grader1_supported, df.grader2_supported), 3)
    out.to_csv(d / "manual_summary.csv", index=False)
    print(out.set_index("system").T.to_string())
    print(f"\nsaved {(d / 'manual_summary.csv').relative_to(config.ROOT)}")


if __name__ == "__main__":
    main()
