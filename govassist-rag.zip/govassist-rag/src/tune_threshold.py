"""Pick the retrieval-score threshold for abstention, using the DEV questions only.

Default: the midpoint that best separates answerable dev questions from
out-of-KB dev questions (maximum balanced accuracy).
With --min-keep 0.95 (used from v3): the highest threshold that still lets at
least 95% of answerable dev questions through. The threshold then acts only as a
coarse "clearly off-topic" filter and the LLM's refusal instruction handles the rest.
User testing showed casually worded answerable questions score as low as clearly
off-topic ones, so a threshold that tries to separate them refuses real questions.
The test set is never used here.

Run:  python -m src.tune_threshold [--retriever dense] [--min-keep 0.95]
"""
import argparse
import json

import numpy as np
import pandas as pd

from . import config
from .ingest import load_chunks
from .retrieve import get_retriever


def best_threshold(scores, answerable):
    scores, answerable = np.asarray(scores), np.asarray(answerable, bool)
    cands = sorted(set(scores))
    mids = [(a + b) / 2 for a, b in zip(cands, cands[1:])] or cands
    best = None
    for t in mids:
        tpr = np.mean(scores[answerable] >= t)   # answerable questions let through
        tnr = np.mean(scores[~answerable] < t)   # out-of-KB questions stopped
        bal = (tpr + tnr) / 2
        # ties -> prefer the lower threshold (fewer false refusals)
        if best is None or bal > best[1] + 1e-9:
            best = (t, bal, tpr, tnr)
    return best


def keep_threshold(scores, answerable, min_keep):
    """Highest threshold that keeps >= min_keep of the answerable questions."""
    scores, answerable = np.asarray(scores), np.asarray(answerable, bool)
    ans = np.sort(scores[answerable])
    k = int(np.floor((1 - min_keep) * len(ans)))       # how many answerable we may lose
    t = ans[k] - 1e-4                                     # just below the (k+1)-th lowest answerable score
    tpr = np.mean(scores[answerable] >= t)
    tnr = np.mean(scores[~answerable] < t)
    return t, (tpr + tnr) / 2, tpr, tnr


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--retriever", default="dense", choices=["bm25", "dense", "hybrid"])
    ap.add_argument("--chunk-words", type=int, default=config.CHUNK_WORDS)
    ap.add_argument("--min-keep", type=float, default=None,
                    help="keep at least this share of answerable dev questions (e.g. 0.95)")
    args = ap.parse_args()

    dev = pd.read_csv(config.DEV_QUESTIONS)
    chunks = load_chunks(args.chunk_words, config.CHUNK_OVERLAP)
    retriever = get_retriever(args.retriever, chunks)
    dev["top1_score"] = [retriever.search(q, 1)[0][1] for q in dev.question]
    dev["answerable"] = dev.question_type != "out_of_kb"
    if args.min_keep:
        t, bal, tpr, tnr = keep_threshold(dev.top1_score, dev.answerable, args.min_keep)
    else:
        t, bal, tpr, tnr = best_threshold(dev.top1_score, dev.answerable)

    print(dev[["question_id", "question_type", "top1_score"]].round(4).to_string(index=False))
    print(f"\nthreshold = {t:.4f}  (dev balanced accuracy {bal:.2f}: {tpr:.0%} of answerable kept, "
          f"{tnr:.0%} of out-of-KB stopped)")
    config.RESULTS_DIR.mkdir(parents=True, exist_ok=True)
    out = {"threshold": round(float(t), 4), "retriever": args.retriever,
           "retriever_score": "bm25" if args.retriever == "bm25" else "cosine",
           "embed_model": config.EMBED_MODEL, "chunk_words": args.chunk_words,
           "dev_balanced_accuracy": round(float(bal), 3), "dev_n": int(len(dev)),
           "rule": f"keep >= {args.min_keep:.0%} of answerable dev questions" if args.min_keep else "max balanced accuracy"}
    path = config.threshold_file(args.retriever)
    path.write_text(json.dumps(out, indent=2))
    print(f"saved {path.relative_to(config.ROOT)}")


if __name__ == "__main__":
    main()
