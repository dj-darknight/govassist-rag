"""Evaluation metrics (implemented here so every number is traceable).

Retrieval: graded NDCG@k, MRR and Hit@k over a *document* ranking. Chunks are
collapsed to their document (first occurrence), because the ground truth is
labelled at document level. Grades: the first document listed for a question
is the primary source (grade 2); any other listed document is grade 1. This
follows Walert's 0/1/2 graded qrels.

Generation: abstention detection, citation parsing/accuracy and ROUGE-1 F1.
"""
import math
import re

try:
    from nltk.stem import PorterStemmer
    _stem = PorterStemmer().stem
except Exception:  # pragma: no cover
    _stem = lambda w: w  # noqa: E731

from . import config


# ---------------------------------------------------------------- ground truth
def graded_qrels(relevant_docs: str):
    """'D03;D02' -> {'D03': 2, 'D02': 1}; 'NONE' -> {}"""
    docs = [d.strip() for d in (relevant_docs or "").split(";") if d.strip() and d.strip() != "NONE"]
    return {d: (2 if i == 0 else 1) for i, d in enumerate(docs)}


# ---------------------------------------------------------------- retrieval
def dcg(gains):
    return sum(g / math.log2(i + 2) for i, g in enumerate(gains))


def ndcg_at_k(ranked_docs, qrels, k):
    if not qrels:
        return None
    gains = [qrels.get(d, 0) for d in ranked_docs[:k]]
    ideal = sorted(qrels.values(), reverse=True)[:k]
    return dcg(gains) / dcg(ideal) if ideal else 0.0


def mrr(ranked_docs, qrels):
    if not qrels:
        return None
    for i, d in enumerate(ranked_docs):
        if d in qrels:
            return 1.0 / (i + 1)
    return 0.0


def hit_at_k(ranked_docs, qrels, k):
    if not qrels:
        return None
    return 1.0 if any(d in qrels for d in ranked_docs[:k]) else 0.0


# ---------------------------------------------------------------- generation
_ABSTAIN_PATTERNS = [
    r"don'?t have enough information",
    r"do not have enough information",
    r"(sources|context|documents|information provided)[^.]{0,60}(do(es)? not|don'?t|doesn'?t) (contain|include|cover|mention|provide|say)",
    r"not (covered|mentioned|included|provided) in (the|my) (sources|context|documents)",
    r"(i|i'm|i am) (not able|unable) to (answer|find)",
    r"cannot (answer|find|determine)",
    r"i don'?t know",
    r"no (relevant )?information (about|on|regarding)",
]


def is_abstention(answer: str) -> bool:
    """True if the answer declines to answer. Only the opening of the answer is checked, so
    'The sources don't say X, but ...' followed by a real answer is not counted as a refusal."""
    a = (answer or "").strip().lower()
    if not a:
        return True
    if config.ABSTAIN_MESSAGE.lower().rstrip(".") in a:
        return True
    opening = re.split(r"(?<=[.!?])\s", a, maxsplit=1)[0][:250]
    if not any(re.search(p, opening) for p in _ABSTAIN_PATTERNS):
        return False
    # "The sources don't cover X, but ..." followed by an actual answer is still an answer
    return not re.search(r"\b(but|however)\b", a)


def cited_docs(answer: str):
    """Extract document IDs cited as [D03] or [D03, D11] (also D03_C002 chunk ids)."""
    found = []
    for group in re.findall(r"\[([^\]]+)\]", answer or ""):
        for d in re.findall(r"D\d{2}", group):
            if d not in found:
                found.append(d)
    return found


def citation_scores(answer, qrels, retrieved_doc_ids):
    """precision: share of cited docs that are relevant; hit: at least one cited doc relevant;
    valid: every cited doc was actually retrieved (no invented citations)."""
    cites = cited_docs(answer)
    if not cites:
        return {"n_cited": 0, "cite_precision": 0.0, "cite_hit": 0.0, "cite_valid": None}
    rel = [d for d in cites if d in qrels]
    return {
        "n_cited": len(cites),
        "cite_precision": len(rel) / len(cites),
        "cite_hit": 1.0 if rel else 0.0,
        "cite_valid": 1.0 if all(d in retrieved_doc_ids for d in cites) else 0.0,
    }


def _rouge_tokens(text):
    # same normalisation as Google's rouge_score (lowercase, non-alphanumerics -> space, Porter stem)
    return [_stem(t) for t in re.sub(r"[^a-z0-9]+", " ", (text or "").lower()).split()]


def rouge1_f(candidate, reference):
    c, r = _rouge_tokens(candidate), _rouge_tokens(reference)
    if not c or not r:
        return 0.0
    counts = {}
    for t in r:
        counts[t] = counts.get(t, 0) + 1
    overlap = 0
    for t in c:
        if counts.get(t, 0) > 0:
            overlap += 1
            counts[t] -= 1
    if overlap == 0:
        return 0.0
    p, rc = overlap / len(c), overlap / len(r)
    return 2 * p * rc / (p + rc)


def strip_citations(text):
    return re.sub(r"\s*\[[^\]]*D\d{2}[^\]]*\]", "", text or "").strip()


def cohens_kappa(a, b):
    """Unweighted Cohen's kappa for two raters' categorical labels."""
    pairs = [(x, y) for x, y in zip(a, b) if x not in (None, "") and y not in (None, "")]
    if not pairs:
        return None
    labels = sorted({x for p in pairs for x in p})
    n = len(pairs)
    po = sum(1 for x, y in pairs if x == y) / n
    pe = sum((sum(1 for x, _ in pairs if x == l) / n) * (sum(1 for _, y in pairs if y == l) / n) for l in labels)
    return 1.0 if pe == 1 else (po - pe) / (1 - pe)


# ---------------------------------------------------------------- number grounding
_NUM_WORDS = {"one": "1", "two": "2", "three": "3", "four": "4", "five": "5", "six": "6", "seven": "7",
              "eight": "8", "nine": "9", "ten": "10", "eleven": "11", "twelve": "12", "fourteen": "14",
              "fifteen": "15", "twenty": "20", "thirty": "30"}


def _numbers(text):
    """Numbers in a text, normalised: '$1,004.90' -> '1004.90', '12%' -> '12', 'two days' -> '2'."""
    text = re.sub(r"\[[^\]]*D\d{2}[^\]]*\]", " ", text or "")         # drop [D03]-style citations
    text = re.sub(r"\b(" + "|".join(_NUM_WORDS) + r")\b", lambda m: _NUM_WORDS[m.group(1).lower()], text,
                  flags=re.I)
    nums = set()
    for n in re.findall(r"\d[\d,]*(?:\.\d+)?", text):
        n = n.replace(",", "")
        nums.add(n.rstrip("0").rstrip(".") if "." in n else n)
    return nums


def unsupported_numbers(answer, source_texts, question=""):
    """Figures in the answer that appear neither in the retrieved passages nor in the question.
    Used as a guard against the LLM inventing rates, dollar amounts or time limits."""
    allowed = _numbers(question)
    for t in source_texts:
        allowed |= _numbers(t)
    trivial = {"0", "1"}  # "no tax", "one shift" etc. carry little risk
    return sorted(_numbers(answer) - allowed - trivial, key=lambda x: float(x))
