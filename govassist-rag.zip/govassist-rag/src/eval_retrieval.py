"""Evaluation #1 — retrieval only (no LLM).

For every retriever x chunk-size configuration, rank documents for each test
question and report graded NDCG@1/3/5, MRR and Hit@3 separately for known and
inferred questions (as in Walert). Also records the top-1 retrieval score for
every question, including out-of-KB ones, to show whether a score threshold can
separate answerable from unanswerable questions.

Run:  python -m src.eval_retrieval                       # defaults below
      python -m src.eval_retrieval --retrievers bm25 --chunk-sizes 200
Outputs (results/retrieval/):
  summary.csv            one row per config x question type
  per_question.csv       ranks and metrics per question
  top_scores.csv         top-1 score per question (for the abstention threshold)
  runs/<config>.trec     TREC run files (document level), usable with ranx/trec_eval
"""
import argparse

import pandas as pd

from . import config
from .ingest import load_chunks
from .metrics import graded_qrels, hit_at_k, mrr, ndcg_at_k
from .retrieve import get_retriever, top_documents

OUT = config.RESULTS_DIR / "retrieval"


def evaluate_config(retriever_name, chunk_words, overlap, questions, depth=20):
    chunks = load_chunks(chunk_words, overlap)
    retriever = get_retriever(retriever_name, chunks)
    tag = f"{retriever_name}_w{chunk_words}"
    rows, run_lines = [], []
    for q in questions.itertuples():
        hits = retriever.search(q.question, depth)
        docs = top_documents(chunks, hits)
        ranked = [d for d, _ in docs]
        qrels = graded_qrels(q.relevant_docs)
        rows.append({
            "config": tag, "retriever": retriever_name, "chunk_words": chunk_words,
            "question_id": q.question_id, "question_type": q.question_type,
            "ookb_kind": q.ookb_kind if isinstance(q.ookb_kind, str) else "",
            "relevant_docs": q.relevant_docs, "top_docs": ";".join(ranked[:5]),
            "top1_score": hits[0][1] if hits else float("nan"),
            "ndcg@1": ndcg_at_k(ranked, qrels, 1), "ndcg@3": ndcg_at_k(ranked, qrels, 3),
            "ndcg@5": ndcg_at_k(ranked, qrels, 5), "mrr": mrr(ranked, qrels), "hit@3": hit_at_k(ranked, qrels, 3),
        })
        for r, (d, s) in enumerate(docs, start=1):
            run_lines.append(f"{q.question_id} Q0 {d} {r} {s:.6f} {tag}")
    runs_dir = OUT / "runs"
    runs_dir.mkdir(parents=True, exist_ok=True)
    (runs_dir / f"{tag}.trec").write_text("\n".join(run_lines) + "\n")
    return rows


def summarise(per_q: pd.DataFrame) -> pd.DataFrame:
    metrics = ["ndcg@1", "ndcg@3", "ndcg@5", "mrr", "hit@3"]
    answerable = per_q[per_q.question_type != "out_of_kb"]
    parts = []
    for qtype, grp in list(answerable.groupby("question_type")) + [("all_answerable", answerable)]:
        s = grp.groupby(["config", "retriever", "chunk_words"])[metrics].mean().reset_index()
        s.insert(3, "question_type", qtype)
        s.insert(4, "n", grp.groupby("config").size().reindex(s.config).values)
        parts.append(s)
    return pd.concat(parts).sort_values(["question_type", "config"]).round(4)


def write_qrels():
    """Document-level qrels in TREC format, for use with ranx or trec_eval."""
    q = pd.read_csv(config.TEST_QUESTIONS)
    lines = [f"{r.question_id} 0 {d} {g}" for r in q.itertuples() for d, g in graded_qrels(r.relevant_docs).items()]
    (OUT / "qrels_test.txt").write_text("\n".join(lines) + "\n")


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--retrievers", nargs="+", default=["bm25", "dense", "hybrid"])
    ap.add_argument("--chunk-sizes", nargs="+", type=int, default=[100, 200, 400])
    ap.add_argument("--overlap", type=int, default=config.CHUNK_OVERLAP)
    args = ap.parse_args()

    questions = pd.read_csv(config.TEST_QUESTIONS)
    OUT.mkdir(parents=True, exist_ok=True)
    write_qrels()
    rows = []
    for size in args.chunk_sizes:
        for name in args.retrievers:
            print(f"  evaluating {name} with {size}-word chunks ...", flush=True)
            rows.extend(evaluate_config(name, size, args.overlap, questions))
    per_q = pd.DataFrame(rows)
    per_q.to_csv(OUT / "per_question.csv", index=False)
    per_q[["config", "question_id", "question_type", "ookb_kind", "top1_score"]].to_csv(OUT / "top_scores.csv", index=False)
    summary = summarise(per_q)
    summary.to_csv(OUT / "summary.csv", index=False)

    pd.set_option("display.width", 160)
    for qtype in ["known", "inferred", "all_answerable"]:
        print(f"\n=== {qtype} questions ===")
        print(summary[summary.question_type == qtype].drop(columns=["question_type"]).to_string(index=False))
    scores = per_q.assign(group=per_q.question_type.where(per_q.question_type == "out_of_kb", "answerable"))
    print("\n=== mean top-1 retrieval score: answerable vs out-of-KB ===")
    print(scores.groupby(["config", "group"]).top1_score.mean().unstack().round(3).to_string())
    print(f"\nSaved to {OUT.relative_to(config.ROOT)}/")


if __name__ == "__main__":
    main()
