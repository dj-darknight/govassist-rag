"""Load the curated government pages and split them into chunks.

Each raw file starts with a small header (title, agency, Source:, last-updated
line, optional curation note) followed by a blank line and the page body.
Sections in the body are separated by blank lines. Chunks are built by packing
whole sections together up to CHUNK_WORDS words; a section longer than that is
split on line boundaries. Consecutive chunks share ~CHUNK_OVERLAP words.

Run:  python -m src.ingest [--chunk-words 200 --overlap 40]
"""
import argparse
import csv
import json
from pathlib import Path

from . import config


def load_inventory():
    with open(config.KB_CSV, newline="", encoding="utf-8") as f:
        return {row["document_id"]: row for row in csv.DictReader(f)}


def parse_raw(path: Path):
    """Split a raw file into its header lines and body text."""
    text = path.read_text(encoding="utf-8").replace("\r\n", "\n")
    header, _, body = text.partition("\n\n")
    return header.strip().splitlines(), body.strip()


def _words(s: str) -> int:
    return len(s.split())


def chunk_body(body: str, size: int, overlap: int):
    """Pack lines into chunks of ~size words.

    A chunk is closed early at a section boundary once it is at least 75% full,
    so chunks tend to align with the page's own sections. Each new chunk starts
    with the last lines (up to `overlap` words) of the previous chunk.
    """
    sections = [s.strip().splitlines() for s in body.split("\n\n") if s.strip()]
    chunks, cur, cur_words, fresh = [], [], 0, 0  # fresh = words added since the last flush

    def flush():
        nonlocal cur, cur_words, fresh
        # Headings left dangling at the end of a chunk belong with the next chunk.
        heading = []
        while cur and cur[-1].strip() and _words(cur[-1]) <= 10 and not cur[-1].rstrip().endswith((".", ";", ",")) \
                and len(cur) > 1:
            heading.insert(0, cur.pop())
        text = "\n".join(cur).strip()
        if text:
            chunks.append(text)
        tail, carried = [], 0
        for line in reversed(cur):
            if not line.strip():
                continue
            if carried + _words(line) > overlap:
                break
            tail.insert(0, line)
            carried += _words(line)
        cur = tail + heading
        cur_words = sum(_words(l) for l in cur)
        fresh = 0
        fresh_from[0] = len(tail)

    fresh_from = [0]  # index in `cur` where lines added since the last flush begin
    for sec in sections:
        if cur_words >= 0.75 * size and fresh:
            flush()
        if cur:
            cur.append("")  # keep a blank line between sections inside a chunk
        for line in sec:
            n = _words(line)
            if cur_words + n > size and fresh:
                flush()
            cur.append(line)
            cur_words += n
            fresh += n
    if chunks and 0 < fresh < 0.25 * size:
        # a short leftover (e.g. a "Source reference" line) is merged into the previous chunk
        chunks[-1] += "\n" + "\n".join(cur[fresh_from[0]:]).rstrip()
    elif fresh or not chunks:
        chunks.append("\n".join(cur).strip())
    return chunks


def build_chunks(chunk_words=None, overlap=None):
    chunk_words = chunk_words or config.CHUNK_WORDS
    overlap = config.CHUNK_OVERLAP if overlap is None else overlap
    inventory = load_inventory()
    out = []
    for doc_id, meta in sorted(inventory.items()):
        path = config.RAW_DIR / meta["filename"]
        _, body = parse_raw(path)
        for i, text in enumerate(chunk_body(body, chunk_words, overlap), start=1):
            out.append({
                "chunk_id": f"{doc_id}_C{i:03d}",
                "document_id": doc_id,
                "title": meta["title"],
                "agency": meta["agency"],
                "topic": meta["topic"],
                "source_url": meta["source_url"],
                "page_last_updated": meta["page_last_updated"],
                "retrieval_date": meta["retrieval_date"],
                # The title is prepended so each chunk says which page it came from;
                # this helps both retrieval and the LLM's citations.
                "text": f"{meta['title']} ({meta['agency']})\n{text}",
            })
    return out


def chunks_path(chunk_words, overlap) -> Path:
    return config.PROCESSED_DIR / f"chunks_w{chunk_words}_o{overlap}.jsonl"


def save_chunks(chunks, path: Path):
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        for c in chunks:
            f.write(json.dumps(c, ensure_ascii=False) + "\n")


def load_chunks(chunk_words=None, overlap=None):
    chunk_words = chunk_words or config.CHUNK_WORDS
    overlap = config.CHUNK_OVERLAP if overlap is None else overlap
    path = chunks_path(chunk_words, overlap)
    if not path.exists():
        save_chunks(build_chunks(chunk_words, overlap), path)
    with open(path, encoding="utf-8") as f:
        return [json.loads(line) for line in f]


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--chunk-words", type=int, default=config.CHUNK_WORDS)
    ap.add_argument("--overlap", type=int, default=config.CHUNK_OVERLAP)
    args = ap.parse_args()
    chunks = build_chunks(args.chunk_words, args.overlap)
    path = chunks_path(args.chunk_words, args.overlap)
    save_chunks(chunks, path)
    sizes = [len(c["text"].split()) for c in chunks]
    per_doc = {}
    for c in chunks:
        per_doc[c["document_id"]] = per_doc.get(c["document_id"], 0) + 1
    print(f"{len(chunks)} chunks from {len(per_doc)} documents -> {path.relative_to(config.ROOT)}")
    print(f"words per chunk: min {min(sizes)}, mean {sum(sizes)/len(sizes):.0f}, max {max(sizes)}")
    print("chunks per document:", ", ".join(f"{d}={n}" for d, n in sorted(per_doc.items())))


if __name__ == "__main__":
    main()
