"""Retrievers: BM25 (lexical baseline), dense (embeddings), and hybrid (RRF of both).

All retrievers return a list of (chunk_index, score) sorted best-first.

The "vector store" is a NumPy matrix of normalised embeddings saved to disk.
With ~100 chunks an exact cosine search is instant, so a separate vector
database (FAISS/Chroma) would add setup cost without changing any result.
"""
import hashlib
import os
import re

import numpy as np
from rank_bm25 import BM25Okapi

from . import config

try:  # Porter stemming, as in Pyserini's default BM25 analyser
    from nltk.stem import PorterStemmer
    _stem = PorterStemmer().stem
except Exception:  # pragma: no cover
    _stem = lambda w: w  # noqa: E731

# Lucene's default English stopword list (the one Pyserini/Anserini uses)
STOPWORDS = set(
    "a an and are as at be but by for if in into is it no not of on or such that the their "
    "then there these they this to was will with".split()
)


def tokenize(text: str):
    return [_stem(t) for t in re.findall(r"[a-z0-9]+", text.lower()) if t not in STOPWORDS]


class BM25Retriever:
    name = "bm25"

    def __init__(self, chunks, k1=0.9, b=0.4):  # k1/b = Pyserini defaults
        self.chunks = chunks
        self.bm25 = BM25Okapi([tokenize(c["text"]) for c in chunks], k1=k1, b=b)

    def search(self, query, k=config.TOP_K):
        scores = self.bm25.get_scores(tokenize(query))
        order = np.argsort(-scores)[:k]
        return [(int(i), float(scores[i])) for i in order]


class _HashingEncoder:
    """Offline stand-in for a sentence-transformer, used only by tests / dry runs
    (GOVASSIST_EMBED_MODEL=mock). Never use it for reported results."""

    def encode(self, texts, normalize_embeddings=True, **_):
        m = np.zeros((len(texts), 2048), dtype=np.float32)
        for r, t in enumerate(texts):
            for tok in tokenize(t):
                m[r, int(hashlib.md5(tok.encode()).hexdigest(), 16) % 2048] += 1.0
        if normalize_embeddings:
            m /= np.linalg.norm(m, axis=1, keepdims=True) + 1e-9
        return m


_ENCODERS = {}


def get_encoder(model_name=None):
    model_name = model_name or config.EMBED_MODEL
    if model_name not in _ENCODERS:
        if model_name == "mock":
            _ENCODERS[model_name] = _HashingEncoder()
        else:
            from sentence_transformers import SentenceTransformer
            _ENCODERS[model_name] = SentenceTransformer(model_name)
    return _ENCODERS[model_name]


class DenseRetriever:
    name = "dense"

    def __init__(self, chunks, model_name=None, query_prefix=None):
        self.chunks = chunks
        self.model_name = model_name or config.EMBED_MODEL
        self.query_prefix = config.QUERY_PREFIX if query_prefix is None else query_prefix
        self.encoder = get_encoder(self.model_name)
        self.matrix = self._load_or_build()

    def _load_or_build(self):
        texts = [c["text"] for c in self.chunks]
        key = hashlib.sha1(("\n\x00".join(texts) + self.model_name).encode()).hexdigest()[:12]
        safe = re.sub(r"[^A-Za-z0-9]+", "_", self.model_name)
        path = config.PROCESSED_DIR / f"emb_{safe}_{key}.npy"
        if path.exists() and self.model_name != "mock":
            return np.load(path)
        m = np.asarray(self.encoder.encode(texts, normalize_embeddings=True, show_progress_bar=False),
                       dtype=np.float32)
        if self.model_name != "mock":
            path.parent.mkdir(parents=True, exist_ok=True)
            np.save(path, m)
        return m

    def search(self, query, k=config.TOP_K):
        q = self.encoder.encode([self.query_prefix + query], normalize_embeddings=True, show_progress_bar=False)
        scores = self.matrix @ np.asarray(q, dtype=np.float32)[0]
        order = np.argsort(-scores)[:k]
        return [(int(i), float(scores[i])) for i in order]


class HybridRetriever:
    """Reciprocal Rank Fusion (Cormack et al., 2009) of BM25 and dense rankings.

    The returned score is the dense cosine score of the chunk, so the same
    abstention threshold can be applied as for the dense retriever."""

    name = "hybrid"

    def __init__(self, chunks, rrf_k=60, depth=20, **dense_kwargs):
        self.chunks = chunks
        self.bm25 = BM25Retriever(chunks)
        self.dense = DenseRetriever(chunks, **dense_kwargs)
        self.rrf_k, self.depth = rrf_k, depth

    def search(self, query, k=config.TOP_K):
        fused, cos = {}, {}
        for rank, (i, _) in enumerate(self.bm25.search(query, self.depth)):
            fused[i] = fused.get(i, 0) + 1 / (self.rrf_k + rank + 1)
        for rank, (i, s) in enumerate(self.dense.search(query, len(self.chunks))):
            cos[i] = s
            if rank < self.depth:
                fused[i] = fused.get(i, 0) + 1 / (self.rrf_k + rank + 1)
        order = sorted(fused, key=fused.get, reverse=True)[:k]
        return [(i, cos[i]) for i in order]


def get_retriever(name, chunks, **kwargs):
    name = name or config.RETRIEVER
    if name == "bm25":
        return BM25Retriever(chunks)
    if name == "dense":
        return DenseRetriever(chunks, **kwargs)
    if name == "hybrid":
        return HybridRetriever(chunks, **kwargs)
    raise ValueError(f"unknown retriever {name!r} (use bm25, dense or hybrid)")


def top_documents(chunks, hits):
    """Collapse a chunk ranking into a document ranking (first occurrence wins)."""
    seen, docs = set(), []
    for i, score in hits:
        d = chunks[i]["document_id"]
        if d not in seen:
            seen.add(d)
            docs.append((d, score))
    return docs


if os.getenv("GOVASSIST_QUIET_HF", "1") == "1":
    os.environ.setdefault("TOKENIZERS_PARALLELISM", "false")
