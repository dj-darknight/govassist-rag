"""Round v3: robustness test + re-tuned threshold + number-grounding check.

    python run_v3.py

1. Measures v2 (current threshold, no number check) on the casual robustness questions -> tag rob_v2
2. Re-tunes the threshold on the expanded dev set so >= 95% of answerable dev questions pass
3. Runs v3 (new threshold + number check) on the test set -> tag v3, and on the robustness set -> rob_v3
4. Remakes the figures
"""
import shutil
import subprocess
import sys

from src import config

ROB = str(config.EVAL_DIR / "robustness_questions.csv")
FINAL = "dense_rag_threshold_prompt"


def run(*args):
    print("\n$ python -m " + " ".join(args), flush=True)
    if subprocess.call([sys.executable, "-m", *args]) != 0:
        sys.exit(f"step failed: {' '.join(args)}")


cur = config.threshold_file("dense")
v2 = cur.with_name("threshold_cosine_v2.json")
if not v2.exists():
    shutil.copy(cur, v2)  # keep the v2 threshold on record
    print(f"saved a copy of the v2 threshold -> {v2.name}")
else:
    shutil.copy(v2, cur)  # re-running: make sure step 1 measures v2 with the v2 threshold

run("pytest", "-q")
run("src.eval_generation", "--tag", "rob_v2", "--questions", ROB, "--systems", "llm_only", FINAL, "--grade")
run("src.tune_threshold", "--retriever", "dense", "--min-keep", "0.95")
run("src.eval_generation", "--tag", "v3", "--number-check", "--systems", "llm_only", FINAL, "--grade", FINAL)
run("src.eval_generation", "--tag", "rob_v3", "--questions", ROB, "--number-check", "--systems", FINAL, "--grade")
run("src.make_figures")
print("\nDone. v3 threshold:", cur.read_text())
