"""GovAssist — Streamlit demo.

Run:  streamlit run app.py
Needs Ollama running with the model in src/config.py (default llama3.2:3b).
"""
import streamlit as st

from src import config
from src.rag import GovAssist, load_threshold

st.set_page_config(page_title="GovAssist", page_icon="🎓", layout="centered")

EXAMPLES = [
    "Can I work more than 48 hours a fortnight during semester break?",
    "My boss pays me cash with no payslip. Is that allowed?",
    "Is a one-week unpaid trial shift legal?",
    "How do I get my super back when I leave Australia?",
    "How do I apply for permanent residency?",  # out of scope: should abstain
]


@st.cache_resource(show_spinner="Loading the knowledge base and models...")
def get_bot(retriever, top_k, use_threshold, use_numcheck):
    return GovAssist(retriever=retriever, top_k=top_k, threshold="auto" if use_threshold else None,
                     number_check=use_numcheck)


with st.sidebar:
    st.header("Settings")
    retriever = st.selectbox("Retriever", ["dense", "hybrid", "bm25"], index=0,
                             help="dense = embeddings; bm25 = keyword baseline; hybrid = both")
    top_k = st.slider("Passages given to the LLM", 2, 8, config.TOP_K)
    use_threshold = st.toggle("Abstain when retrieval confidence is low", value=True)
    use_numcheck = st.toggle("Withhold answers with figures not in the sources", value=config.NUMBER_CHECK)
    t = load_threshold(retriever)
    if use_threshold and not t:
        st.warning("No threshold tuned yet — run `python -m src.tune_threshold`.")
    elif use_threshold and t:
        st.caption(f"Threshold {t['threshold']:.3f} (tuned on the dev set)")
    st.caption(f"LLM: `{config.LLM_MODEL}` via Ollama · embeddings: `{config.EMBED_MODEL}`")
    st.divider()
    st.caption("Knowledge base: 15 official pages from Fair Work, Home Affairs, Study Australia and the ATO, "
               "retrieved 29 Sep 2026.")

st.title("GovAssist")
st.subheader("Working while studying in Australia")
st.info(config.DISCLAIMER, icon="ℹ️")

st.write("Try an example:")
cols = st.columns(2)
for i, ex in enumerate(EXAMPLES):
    if cols[i % 2].button(ex, key=f"ex{i}", use_container_width=True):
        st.session_state.question = ex

question = st.text_input("Your question", key="question", placeholder="e.g. How many hours can I work on a student visa?")

if st.button("Ask", type="primary") and question.strip():
    try:
        bot = get_bot(retriever, top_k, use_threshold, use_numcheck)
        with st.spinner("Searching official sources..."):
            result = bot.answer(question.strip())
    except Exception as e:  # most often: Ollama not running or model not pulled
        st.error(f"Could not answer: {e}\n\nIs Ollama running, and have you pulled `{config.LLM_MODEL}`?")
        st.stop()

    st.markdown("### Answer")
    if result["abstained"]:
        st.warning(config.ABSTAIN_MESSAGE, icon="🛑")
        if result.get("abstain_reason") == "threshold":
            st.caption(f"Nothing in the knowledge base matched closely enough "
                       f"(best match {result['top_score']:.3f}, threshold {result['threshold']:.3f}). "
                       "Try the Department of Home Affairs (13 18 81) or the Fair Work Ombudsman (13 13 94).")
        elif result.get("abstain_reason") == "unsupported_number":
            st.caption("A draft answer was withheld because it contained a figure "
                       f"({', '.join(result['unsupported_numbers'])}) that does not appear in the official pages.")
        else:
            st.caption("The retrieved official pages don't cover this question.")
    else:
        st.write(result["answer"])
        if result.get("invalid_citations"):
            st.caption(f"⚠️ The model cited sources it wasn't given: {', '.join(result['invalid_citations'])}")

    if bot.retriever_name in ("dense", "hybrid") and result["top_score"] is not None:
        conf = max(0.0, min(1.0, (result["top_score"] - 0.3) / 0.5))
        st.progress(conf, text=f"Retrieval match strength: {result['top_score']:.3f} (cosine similarity)")

    cited = set(result["citations"])
    docs = {}
    for c in result["retrieved"]:
        docs.setdefault(c["document_id"], c)
    if docs:
        st.markdown("### Sources" if not result["abstained"] else "### Closest official pages (not a match)")
        for doc_id, c in docs.items():
            badge = "✅ cited" if doc_id in cited else "retrieved, not cited"
            with st.container(border=True):
                st.markdown(f"**[{doc_id}] [{c['title']}]({c['source_url']})** · {badge}")
                st.caption(f"{c['agency']} · page updated {c['page_last_updated']} · retrieved {c['retrieval_date']}")

        with st.expander("Show the retrieved passages"):
            for c in result["retrieved"]:
                st.markdown(f"**{c['chunk_id']}** · score {c['score']:.3f}")
                st.text(c["text"][:1200])
